package edu.cg;

public class BestPath {
	final long pixelMin;
	final int pathMin;
	
	BestPath(long min, int pathMin) {
		this.pixelMin = min;
		this.pathMin = pathMin;
	}
}