 Show Seams Documentation

 /**
    * The following method presents vertical and horizontal Seams on the GUI module
    * Iterating over all seams, we iterate over the seam length each iteration.
    * For every seam we iterate over the y coordinates and color the pixels by 
    * setting the color by the input color.
    * This is all done ontop of a duplicated version of the current working image
    * which is later returned
    * 
    * @param seamColorRGB - color for the seam pixels
    * @return result - a duplication of working image with the seam marks
    */
 