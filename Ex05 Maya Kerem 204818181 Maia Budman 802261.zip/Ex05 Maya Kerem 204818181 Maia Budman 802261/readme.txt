Introduction to Computer Graphics HW5 - 204818181 - 802261

(Mandetory) Design Feature 1 - Back Pipes:
- We created a class called BackPipes that renders two cyliners that are placed 90 degrees to the y axis and have a space that is 0.06 distance between each other. Bounding the axis. We also colored them Sand Color. 

(Bonus) Design Freature 2 - Decorations:
- Adapted the background color gl.glClearColor(0.2f, 0.2f, 0.2f, 1) in the viewer class
- Adapter the color scheme of the car to be ocean like (Different color values of green and blue)
- Adapted the color of the light bulbs to be the same as the pipe's, sand color. 
- Added wings to the car in the color of sand so that in year 2150 the car can also be used as a plane (Adjusted the size of the base box) 