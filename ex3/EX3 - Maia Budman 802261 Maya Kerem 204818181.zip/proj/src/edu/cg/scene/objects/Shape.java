package edu.cg.scene.objects;


public abstract class Shape implements Intersectable {
	// An abstract class the represents a shape.
	// You can add abstract methods here.
}
